from qiskit.visualization import plot_state_city

state = [[ 0.75  , 0.433j],
         [-0.433j, 0.25  ]]
plot_state_city(state)