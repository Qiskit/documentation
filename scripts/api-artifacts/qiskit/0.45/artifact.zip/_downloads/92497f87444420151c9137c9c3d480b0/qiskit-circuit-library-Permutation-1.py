from qiskit.circuit.library import Permutation
A = [2,4,3,0,1]
circuit = Permutation(5, A)
circuit.draw('mpl')