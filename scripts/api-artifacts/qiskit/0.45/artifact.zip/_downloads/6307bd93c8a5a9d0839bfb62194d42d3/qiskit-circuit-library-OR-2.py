from qiskit.circuit.library import OR
from qiskit.tools.jupyter.library import _generate_circuit_library_visualization
circuit = OR(5, flags=[-1, 0, 0, 1, 1])
_generate_circuit_library_visualization(circuit)