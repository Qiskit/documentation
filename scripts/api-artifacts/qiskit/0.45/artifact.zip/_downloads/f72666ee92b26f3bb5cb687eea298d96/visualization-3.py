from qiskit.visualization import plot_histogram

counts = {"00": 501, "11": 499}
plot_histogram(counts)