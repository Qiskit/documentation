from qiskit.circuit.library import InnerProduct
from qiskit.tools.jupyter.library import _generate_circuit_library_visualization
circuit = InnerProduct(4)
_generate_circuit_library_visualization(circuit)