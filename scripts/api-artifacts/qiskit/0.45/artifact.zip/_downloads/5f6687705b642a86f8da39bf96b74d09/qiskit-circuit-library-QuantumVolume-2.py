from qiskit.circuit.library import QuantumVolume
from qiskit.tools.jupyter.library import _generate_circuit_library_visualization
circuit = QuantumVolume(5, 6, seed=10, classical_permutation=False)
_generate_circuit_library_visualization(circuit.decompose())