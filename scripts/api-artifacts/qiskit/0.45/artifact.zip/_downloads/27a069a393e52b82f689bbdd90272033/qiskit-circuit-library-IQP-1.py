from qiskit.circuit.library import IQP
A = [[6, 5, 3], [5, 4, 5], [3, 5, 1]]
circuit = IQP(A)
circuit.draw('mpl')