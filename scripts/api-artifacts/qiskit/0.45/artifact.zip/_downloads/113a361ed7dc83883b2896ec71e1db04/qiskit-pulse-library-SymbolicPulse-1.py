import sympy
from qiskit.pulse.library import SymbolicPulse

t, amp, freq = sympy.symbols("t, amp, freq")
envelope = 2 * amp * (freq * t - sympy.floor(1 / 2 + freq * t))

my_pulse = SymbolicPulse(
    pulse_type="Sawtooth",
    duration=100,
    parameters={"amp": 0.1, "freq": 0.05},
    envelope=envelope,
    name="pulse1",
)

my_pulse.draw()