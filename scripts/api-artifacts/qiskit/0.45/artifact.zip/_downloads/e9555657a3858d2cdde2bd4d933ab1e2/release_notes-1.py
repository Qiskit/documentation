from qiskit.visualization import plot_coupling_map
from rustworkx.generators import grid_graph
graph = grid_graph(50, 10)
plot_coupling_map(len(graph), None, graph.edge_list())