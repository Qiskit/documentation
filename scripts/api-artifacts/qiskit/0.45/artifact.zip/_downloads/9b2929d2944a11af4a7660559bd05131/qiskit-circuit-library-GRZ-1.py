from qiskit.circuit.library import GRZ
from qiskit.tools.jupyter.library import _generate_circuit_library_visualization
import numpy as np
circuit = GRZ(num_qubits=3, phi=np.pi/2)
_generate_circuit_library_visualization(circuit)