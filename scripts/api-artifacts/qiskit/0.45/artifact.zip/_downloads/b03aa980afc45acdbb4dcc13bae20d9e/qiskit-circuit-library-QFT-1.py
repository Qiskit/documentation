from qiskit.circuit.library import QFT
from qiskit.tools.jupyter.library import _generate_circuit_library_visualization
circuit = QFT(4)
_generate_circuit_library_visualization(circuit)