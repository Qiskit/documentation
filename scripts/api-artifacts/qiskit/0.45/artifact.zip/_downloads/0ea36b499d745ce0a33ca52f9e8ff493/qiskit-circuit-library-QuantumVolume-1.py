from qiskit.circuit.library import QuantumVolume
circuit = QuantumVolume(5, 6, seed=10)
circuit.draw('mpl')