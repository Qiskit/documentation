from qiskit.circuit.library import QFT
from qiskit.tools.jupyter.library import _generate_circuit_library_visualization
circuit = QFT(5, approximation_degree=2)
_generate_circuit_library_visualization(circuit)