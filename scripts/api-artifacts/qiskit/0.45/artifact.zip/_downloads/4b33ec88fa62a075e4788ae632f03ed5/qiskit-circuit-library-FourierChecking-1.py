from qiskit.circuit.library import FourierChecking
from qiskit.tools.jupyter.library import _generate_circuit_library_visualization
f = [1, -1, -1, -1]
g = [1, 1, -1, -1]
circuit = FourierChecking(f, g)
_generate_circuit_library_visualization(circuit)