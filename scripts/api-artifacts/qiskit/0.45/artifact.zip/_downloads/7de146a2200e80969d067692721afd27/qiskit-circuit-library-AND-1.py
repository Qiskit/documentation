from qiskit.circuit.library import AND
from qiskit.tools.jupyter.library import _generate_circuit_library_visualization
circuit = AND(5)
_generate_circuit_library_visualization(circuit)