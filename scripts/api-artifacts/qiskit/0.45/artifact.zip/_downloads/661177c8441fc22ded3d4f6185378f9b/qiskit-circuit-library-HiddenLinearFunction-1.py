from qiskit.circuit.library import HiddenLinearFunction
from qiskit.tools.jupyter.library import _generate_circuit_library_visualization
A = [[1, 1, 0], [1, 0, 1], [0, 1, 1]]
circuit = HiddenLinearFunction(A)
_generate_circuit_library_visualization(circuit)