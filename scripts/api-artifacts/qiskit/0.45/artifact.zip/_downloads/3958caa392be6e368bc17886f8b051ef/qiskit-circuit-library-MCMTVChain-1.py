from qiskit.circuit.library import MCMTVChain, ZGate
from qiskit.tools.jupyter.library import _generate_circuit_library_visualization
circuit = MCMTVChain(ZGate(), 2, 2)
_generate_circuit_library_visualization(circuit.decompose())