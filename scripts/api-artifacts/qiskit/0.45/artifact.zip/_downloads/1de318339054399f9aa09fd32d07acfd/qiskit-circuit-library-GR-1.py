from qiskit.circuit.library import GR
from qiskit.tools.jupyter.library import _generate_circuit_library_visualization
import numpy as np
circuit = GR(num_qubits=3, theta=np.pi/4, phi=np.pi/2)
_generate_circuit_library_visualization(circuit)