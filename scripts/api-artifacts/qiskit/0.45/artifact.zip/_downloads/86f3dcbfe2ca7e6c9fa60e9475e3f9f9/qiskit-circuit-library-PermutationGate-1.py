from qiskit.circuit.quantumcircuit import QuantumCircuit
from qiskit.circuit.library import PermutationGate
A = [2,4,3,0,1]
permutation = PermutationGate(A)
circuit = QuantumCircuit(5)
circuit.append(permutation, [0, 1, 2, 3, 4])
circuit.draw('mpl')