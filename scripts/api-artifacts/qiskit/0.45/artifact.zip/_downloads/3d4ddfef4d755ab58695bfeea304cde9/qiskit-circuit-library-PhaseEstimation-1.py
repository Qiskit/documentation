from qiskit.circuit import QuantumCircuit
from qiskit.circuit.library import PhaseEstimation
from qiskit.tools.jupyter.library import _generate_circuit_library_visualization
unitary = QuantumCircuit(2)
unitary.x(0)
unitary.y(1)
circuit = PhaseEstimation(3, unitary)
_generate_circuit_library_visualization(circuit)