﻿

ResilienceOptions
============================================

.. currentmodule:: qiskit_ibm_runtime.options

.. autoclass:: ResilienceOptions
   :no-members:
   :no-inherited-members:
   :no-special-members:


   
   .. rubric:: Attributes
      
   .. autoattribute:: ResilienceOptions.extrapolator
   .. autoattribute:: ResilienceOptions.noise_amplifier
   .. autoattribute:: ResilienceOptions.noise_factors
   



   
   .. rubric:: Methods
   
   .. automethod:: ResilienceOptions.validate_resilience_options

   
