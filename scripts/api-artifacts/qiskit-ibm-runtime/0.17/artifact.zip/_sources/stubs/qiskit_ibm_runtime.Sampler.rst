﻿

Sampler
==========================

.. currentmodule:: qiskit_ibm_runtime

.. autoclass:: Sampler
   :no-members:
   :no-inherited-members:
   :no-special-members:


   
   .. rubric:: Attributes
      
   .. autoattribute:: Sampler.circuits
   .. autoattribute:: Sampler.options
   .. autoattribute:: Sampler.parameters
   .. autoattribute:: Sampler.session
   



   
   .. rubric:: Methods
   
   .. automethod:: Sampler.run
   .. automethod:: Sampler.set_options

   
