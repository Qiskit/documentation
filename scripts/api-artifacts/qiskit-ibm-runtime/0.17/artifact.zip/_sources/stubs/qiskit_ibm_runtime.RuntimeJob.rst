﻿

RuntimeJob
=============================

.. currentmodule:: qiskit_ibm_runtime

.. autoclass:: RuntimeJob
   :no-members:
   :no-inherited-members:
   :no-special-members:


   
   .. rubric:: Attributes
      
   .. autoattribute:: RuntimeJob.creation_date
   .. autoattribute:: RuntimeJob.image
   .. autoattribute:: RuntimeJob.inputs
   .. autoattribute:: RuntimeJob.program_id
   .. autoattribute:: RuntimeJob.session_id
   .. autoattribute:: RuntimeJob.tags
   .. autoattribute:: RuntimeJob.usage_estimation
   .. autoattribute:: RuntimeJob.version
   



   
   .. rubric:: Methods
   
   .. automethod:: RuntimeJob.backend
   .. automethod:: RuntimeJob.cancel
   .. automethod:: RuntimeJob.cancel_result_streaming
   .. automethod:: RuntimeJob.cancelled
   .. automethod:: RuntimeJob.done
   .. automethod:: RuntimeJob.error_message
   .. automethod:: RuntimeJob.in_final_state
   .. automethod:: RuntimeJob.interim_results
   .. automethod:: RuntimeJob.job_id
   .. automethod:: RuntimeJob.logs
   .. automethod:: RuntimeJob.metrics
   .. automethod:: RuntimeJob.properties
   .. automethod:: RuntimeJob.result
   .. automethod:: RuntimeJob.running
   .. automethod:: RuntimeJob.status
   .. automethod:: RuntimeJob.stream_results
   .. automethod:: RuntimeJob.submit
   .. automethod:: RuntimeJob.update_tags
   .. automethod:: RuntimeJob.wait_for_final_state

   
