﻿

Options
==================================

.. currentmodule:: qiskit_ibm_runtime.options

.. autoclass:: Options
   :no-members:
   :no-inherited-members:
   :no-special-members:


   
   .. rubric:: Attributes
      
   .. autoattribute:: Options.max_execution_time
   .. autoattribute:: Options.optimization_level
   .. autoattribute:: Options.resilience_level
   .. autoattribute:: Options.transpilation
   .. autoattribute:: Options.resilience
   .. autoattribute:: Options.execution
   .. autoattribute:: Options.environment
   .. autoattribute:: Options.simulator
   



   
   .. rubric:: Methods
   
   .. automethod:: Options.validate_options

   
