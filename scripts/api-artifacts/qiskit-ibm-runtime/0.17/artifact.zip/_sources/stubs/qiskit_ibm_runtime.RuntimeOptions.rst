﻿

RuntimeOptions
=================================

.. currentmodule:: qiskit_ibm_runtime

.. autoclass:: RuntimeOptions
   :no-members:
   :no-inherited-members:
   :no-special-members:


   
   .. rubric:: Attributes
      
   .. autoattribute:: RuntimeOptions.backend
   .. autoattribute:: RuntimeOptions.image
   .. autoattribute:: RuntimeOptions.instance
   .. autoattribute:: RuntimeOptions.job_tags
   .. autoattribute:: RuntimeOptions.log_level
   .. autoattribute:: RuntimeOptions.max_execution_time
   .. autoattribute:: RuntimeOptions.session_time
   



   
   .. rubric:: Methods
   
   .. automethod:: RuntimeOptions.validate

   
