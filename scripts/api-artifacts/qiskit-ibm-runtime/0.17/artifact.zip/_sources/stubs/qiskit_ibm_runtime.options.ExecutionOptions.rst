﻿

ExecutionOptions
===========================================

.. currentmodule:: qiskit_ibm_runtime.options

.. autoclass:: ExecutionOptions
   :no-members:
   :no-inherited-members:
   :no-special-members:


   
   .. rubric:: Attributes
      
   .. autoattribute:: ExecutionOptions.init_qubits
   .. autoattribute:: ExecutionOptions.shots
   



   
   .. rubric:: Methods
   
   .. automethod:: ExecutionOptions.validate_execution_options

   
