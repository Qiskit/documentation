﻿

RuntimeDecoder
=================================

.. currentmodule:: qiskit_ibm_runtime

.. autoclass:: RuntimeDecoder
   :no-members:
   :no-inherited-members:
   :no-special-members:


   



   
   .. rubric:: Methods
   
   .. automethod:: RuntimeDecoder.decode
   .. automethod:: RuntimeDecoder.object_hook
   .. automethod:: RuntimeDecoder.raw_decode

   
