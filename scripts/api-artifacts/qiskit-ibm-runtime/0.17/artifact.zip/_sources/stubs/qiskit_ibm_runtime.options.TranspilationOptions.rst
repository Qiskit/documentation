﻿

TranspilationOptions
===============================================

.. currentmodule:: qiskit_ibm_runtime.options

.. autoclass:: TranspilationOptions
   :no-members:
   :no-inherited-members:
   :no-special-members:


   
   .. rubric:: Attributes
      
   .. autoattribute:: TranspilationOptions.approximation_degree
   .. autoattribute:: TranspilationOptions.initial_layout
   .. autoattribute:: TranspilationOptions.layout_method
   .. autoattribute:: TranspilationOptions.routing_method
   .. autoattribute:: TranspilationOptions.skip_transpilation
   



   
   .. rubric:: Methods
   
   .. automethod:: TranspilationOptions.validate_transpilation_options

   
