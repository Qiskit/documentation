﻿

Estimator
============================

.. currentmodule:: qiskit_ibm_runtime

.. autoclass:: Estimator
   :no-members:
   :no-inherited-members:
   :no-special-members:


   
   .. rubric:: Attributes
      
   .. autoattribute:: Estimator.circuits
   .. autoattribute:: Estimator.observables
   .. autoattribute:: Estimator.options
   .. autoattribute:: Estimator.parameters
   .. autoattribute:: Estimator.session
   



   
   .. rubric:: Methods
   
   .. automethod:: Estimator.run
   .. automethod:: Estimator.set_options

   
