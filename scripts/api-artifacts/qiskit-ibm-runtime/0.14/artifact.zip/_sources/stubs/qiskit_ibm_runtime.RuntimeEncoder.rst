﻿

RuntimeEncoder
=================================

.. currentmodule:: qiskit_ibm_runtime

.. autoclass:: RuntimeEncoder
   :no-members:
   :no-inherited-members:
   :no-special-members:


   
   .. rubric:: Attributes
      
   .. autoattribute:: RuntimeEncoder.item_separator
   .. autoattribute:: RuntimeEncoder.key_separator
   



   
   .. rubric:: Methods
   
   .. automethod:: RuntimeEncoder.default
   .. automethod:: RuntimeEncoder.encode
   .. automethod:: RuntimeEncoder.iterencode

   
