﻿

QiskitRuntimeService
=======================================

.. currentmodule:: qiskit_ibm_runtime

.. autoclass:: QiskitRuntimeService
   :no-members:
   :no-inherited-members:
   :no-special-members:


   
   .. rubric:: Attributes
      
   .. autoattribute:: QiskitRuntimeService.channel
   .. autoattribute:: QiskitRuntimeService.global_service
   .. autoattribute:: QiskitRuntimeService.runtime
   .. autoattribute:: QiskitRuntimeService.version
   



   
   .. rubric:: Methods
   
   .. automethod:: QiskitRuntimeService.active_account
   .. automethod:: QiskitRuntimeService.backend
   .. automethod:: QiskitRuntimeService.backends
   .. automethod:: QiskitRuntimeService.delete_account
   .. automethod:: QiskitRuntimeService.delete_job
   .. automethod:: QiskitRuntimeService.delete_program
   .. automethod:: QiskitRuntimeService.get_backend
   .. automethod:: QiskitRuntimeService.instances
   .. automethod:: QiskitRuntimeService.job
   .. automethod:: QiskitRuntimeService.jobs
   .. automethod:: QiskitRuntimeService.least_busy
   .. automethod:: QiskitRuntimeService.pprint_programs
   .. automethod:: QiskitRuntimeService.program
   .. automethod:: QiskitRuntimeService.programs
   .. automethod:: QiskitRuntimeService.run
   .. automethod:: QiskitRuntimeService.save_account
   .. automethod:: QiskitRuntimeService.saved_accounts
   .. automethod:: QiskitRuntimeService.set_program_visibility
   .. automethod:: QiskitRuntimeService.update_program
   .. automethod:: QiskitRuntimeService.upload_program

   
