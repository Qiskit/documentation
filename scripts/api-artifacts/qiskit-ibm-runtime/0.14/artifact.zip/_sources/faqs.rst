.. _faqs:

#########################################
Frequently asked questions
#########################################

.. toctree::
    faqs/open_source_vs_ibm_cloud_primitives
    faqs/max_execution_time
    FAQs for IBM Cloud Qiskit Runtime <https://cloud.ibm.com/docs/quantum-computing?topic=quantum-computing-qiskit-runtime-faqs>



.. Hiding - Indices and tables
   :ref:`genindex`
   :ref:`modindex`
   :ref:`search`
