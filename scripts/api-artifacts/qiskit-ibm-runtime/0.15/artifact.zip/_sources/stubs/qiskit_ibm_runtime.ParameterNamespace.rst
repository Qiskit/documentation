﻿

ParameterNamespace
=====================================

.. currentmodule:: qiskit_ibm_runtime

.. autoclass:: ParameterNamespace
   :no-members:
   :no-inherited-members:
   :no-special-members:


   
   .. rubric:: Attributes
      
   .. autoattribute:: ParameterNamespace.metadata
   



   
   .. rubric:: Methods
   
   .. automethod:: ParameterNamespace.to_dict
   .. automethod:: ParameterNamespace.validate

   
