﻿

RuntimeProgram
=================================

.. currentmodule:: qiskit_ibm_runtime

.. autoclass:: RuntimeProgram
   :no-members:
   :no-inherited-members:
   :no-special-members:


   
   .. rubric:: Attributes
      
   .. autoattribute:: RuntimeProgram.backend_requirements
   .. autoattribute:: RuntimeProgram.creation_date
   .. autoattribute:: RuntimeProgram.data
   .. autoattribute:: RuntimeProgram.description
   .. autoattribute:: RuntimeProgram.interim_results
   .. autoattribute:: RuntimeProgram.is_public
   .. autoattribute:: RuntimeProgram.max_execution_time
   .. autoattribute:: RuntimeProgram.name
   .. autoattribute:: RuntimeProgram.program_id
   .. autoattribute:: RuntimeProgram.return_values
   .. autoattribute:: RuntimeProgram.update_date
   



   
   .. rubric:: Methods
   
   .. automethod:: RuntimeProgram.parameters
   .. automethod:: RuntimeProgram.to_dict

   
