﻿

SimulatorOptions
===========================================

.. currentmodule:: qiskit_ibm_runtime.options

.. autoclass:: SimulatorOptions
   :no-members:
   :no-inherited-members:
   :no-special-members:


   
   .. rubric:: Attributes
      
   .. autoattribute:: SimulatorOptions.basis_gates
   .. autoattribute:: SimulatorOptions.coupling_map
   .. autoattribute:: SimulatorOptions.noise_model
   .. autoattribute:: SimulatorOptions.seed_simulator
   



   
   .. rubric:: Methods
   
   .. automethod:: SimulatorOptions.set_backend
   .. automethod:: SimulatorOptions.validate_simulator_options

   
