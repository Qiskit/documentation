﻿

Session
==========================

.. currentmodule:: qiskit_ibm_runtime

.. autoclass:: Session
   :no-members:
   :no-inherited-members:
   :no-special-members:


   
   .. rubric:: Attributes
      
   .. autoattribute:: Session.service
   .. autoattribute:: Session.session_id
   



   
   .. rubric:: Methods
   
   .. automethod:: Session.backend
   .. automethod:: Session.cancel
   .. automethod:: Session.close
   .. automethod:: Session.details
   .. automethod:: Session.from_id
   .. automethod:: Session.run
   .. automethod:: Session.status

   
