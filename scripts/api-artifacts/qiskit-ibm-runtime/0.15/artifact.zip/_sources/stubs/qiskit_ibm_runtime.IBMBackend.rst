﻿

IBMBackend
=============================

.. currentmodule:: qiskit_ibm_runtime

.. autoclass:: IBMBackend
   :no-members:
   :no-inherited-members:
   :no-special-members:


   
   .. rubric:: Attributes
      
   .. autoattribute:: IBMBackend.coupling_map
   .. autoattribute:: IBMBackend.dt
   .. autoattribute:: IBMBackend.dtm
   .. autoattribute:: IBMBackend.id_warning_issued
   .. autoattribute:: IBMBackend.instruction_durations
   .. autoattribute:: IBMBackend.instruction_schedule_map
   .. autoattribute:: IBMBackend.instructions
   .. autoattribute:: IBMBackend.max_circuits
   .. autoattribute:: IBMBackend.meas_map
   .. autoattribute:: IBMBackend.num_qubits
   .. autoattribute:: IBMBackend.operation_names
   .. autoattribute:: IBMBackend.operations
   .. autoattribute:: IBMBackend.options
   .. autoattribute:: IBMBackend.provider
   .. autoattribute:: IBMBackend.service
   .. autoattribute:: IBMBackend.session
   .. autoattribute:: IBMBackend.target
   .. autoattribute:: IBMBackend.version
   .. autoattribute:: IBMBackend.name
   .. autoattribute:: IBMBackend.description
   .. autoattribute:: IBMBackend.online_date
   .. autoattribute:: IBMBackend.backend_version
   



   
   .. rubric:: Methods
   
   .. automethod:: IBMBackend.__call__
   .. automethod:: IBMBackend.acquire_channel
   .. automethod:: IBMBackend.cancel_session
   .. automethod:: IBMBackend.check_faulty
   .. automethod:: IBMBackend.close_session
   .. automethod:: IBMBackend.configuration
   .. automethod:: IBMBackend.control_channel
   .. automethod:: IBMBackend.defaults
   .. automethod:: IBMBackend.drive_channel
   .. automethod:: IBMBackend.measure_channel
   .. automethod:: IBMBackend.open_session
   .. automethod:: IBMBackend.properties
   .. automethod:: IBMBackend.qubit_properties
   .. automethod:: IBMBackend.run
   .. automethod:: IBMBackend.set_options
   .. automethod:: IBMBackend.status
   .. automethod:: IBMBackend.target_history

   
