

IBMCompositeJob.in_final_state
======================================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: IBMCompositeJob.in_final_state