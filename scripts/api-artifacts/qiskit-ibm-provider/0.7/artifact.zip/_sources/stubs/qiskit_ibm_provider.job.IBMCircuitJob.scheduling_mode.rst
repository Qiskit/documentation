

IBMCircuitJob.scheduling_mode
=====================================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: IBMCircuitJob.scheduling_mode