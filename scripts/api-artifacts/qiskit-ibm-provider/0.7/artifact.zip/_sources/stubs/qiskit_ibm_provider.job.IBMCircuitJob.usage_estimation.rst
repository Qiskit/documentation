

IBMCircuitJob.usage_estimation
======================================================

.. currentmodule:: qiskit_ibm_provider.job

.. autoproperty:: IBMCircuitJob.usage_estimation