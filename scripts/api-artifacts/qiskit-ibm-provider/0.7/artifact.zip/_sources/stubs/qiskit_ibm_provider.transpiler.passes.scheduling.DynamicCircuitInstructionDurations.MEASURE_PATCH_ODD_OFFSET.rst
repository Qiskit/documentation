

DynamicCircuitInstructionDurations.MEASURE_PATCH_ODD_OFFSET
============================================================================================================

.. currentmodule:: qiskit_ibm_provider.transpiler.passes.scheduling

.. autoattribute:: DynamicCircuitInstructionDurations.MEASURE_PATCH_ODD_OFFSET