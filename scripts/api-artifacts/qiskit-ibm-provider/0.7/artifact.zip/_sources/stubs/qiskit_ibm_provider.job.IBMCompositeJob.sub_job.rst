

IBMCompositeJob.sub_job
===============================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: IBMCompositeJob.sub_job