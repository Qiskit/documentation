

IBMCircuitJob.version
=============================================

.. currentmodule:: qiskit_ibm_provider.job

.. autoattribute:: IBMCircuitJob.version