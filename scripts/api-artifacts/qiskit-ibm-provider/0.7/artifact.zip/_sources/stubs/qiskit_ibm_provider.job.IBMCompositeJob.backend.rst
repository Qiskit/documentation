

IBMCompositeJob.backend
===============================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: IBMCompositeJob.backend