

PadDelay
=========================================================

.. currentmodule:: qiskit_ibm_provider.transpiler.passes.scheduling

.. autoclass:: PadDelay
   :no-members:
   :no-inherited-members:
   :no-special-members:

   
   

   .. rubric:: Attributes

   .. autosummary::
      :toctree: ../stubs/
   
      PadDelay.is_analysis_pass
      PadDelay.is_transformation_pass
   
   

   
   

   .. rubric:: Methods

   .. autosummary::
      :toctree: ../stubs/
   
      PadDelay.__call__
      PadDelay.execute
      PadDelay.name
      PadDelay.run
      PadDelay.update_status
   
      PadDelay.__call__

   
   