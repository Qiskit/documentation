

IBMCompositeJob.cancel
==============================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: IBMCompositeJob.cancel