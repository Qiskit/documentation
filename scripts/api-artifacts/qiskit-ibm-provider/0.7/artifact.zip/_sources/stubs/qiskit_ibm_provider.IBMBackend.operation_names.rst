

IBMBackend.operation_names
==============================================

.. currentmodule:: qiskit_ibm_provider

.. autoproperty:: IBMBackend.operation_names