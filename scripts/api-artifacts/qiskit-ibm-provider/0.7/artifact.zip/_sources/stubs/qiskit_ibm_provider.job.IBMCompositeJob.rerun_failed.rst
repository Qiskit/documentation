

IBMCompositeJob.rerun_failed
====================================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: IBMCompositeJob.rerun_failed