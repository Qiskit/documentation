

IBMProvider.jobs
====================================

.. currentmodule:: qiskit_ibm_provider

.. automethod:: IBMProvider.jobs