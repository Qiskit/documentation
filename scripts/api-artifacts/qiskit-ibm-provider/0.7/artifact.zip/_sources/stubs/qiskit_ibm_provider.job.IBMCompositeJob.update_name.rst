

IBMCompositeJob.update_name
===================================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: IBMCompositeJob.update_name