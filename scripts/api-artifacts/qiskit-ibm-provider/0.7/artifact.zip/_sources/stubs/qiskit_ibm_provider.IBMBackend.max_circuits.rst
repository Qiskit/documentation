

IBMBackend.max_circuits
===========================================

.. currentmodule:: qiskit_ibm_provider

.. autoproperty:: IBMBackend.max_circuits