

IBMCompositeJob.sub_jobs
================================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: IBMCompositeJob.sub_jobs