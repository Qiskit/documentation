

IBMBackend.acquire_channel
==============================================

.. currentmodule:: qiskit_ibm_provider

.. automethod:: IBMBackend.acquire_channel