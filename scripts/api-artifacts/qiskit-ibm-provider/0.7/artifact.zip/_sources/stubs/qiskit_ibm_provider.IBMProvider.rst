﻿

IBMProvider
===============================

.. currentmodule:: qiskit_ibm_provider

.. autoclass:: IBMProvider
   :no-members:
   :no-inherited-members:
   :no-special-members:

   
   

   .. rubric:: Attributes

   .. autosummary::
      :toctree: ../stubs/
   
      IBMProvider.backend
      IBMProvider.version
   
   

   
   

   .. rubric:: Methods

   .. autosummary::
      :toctree: ../stubs/
   
      IBMProvider.active_account
      IBMProvider.backends
      IBMProvider.delete_account
      IBMProvider.get_backend
      IBMProvider.instances
      IBMProvider.jobs
      IBMProvider.retrieve_job
      IBMProvider.save_account
      IBMProvider.saved_accounts
   

   
   