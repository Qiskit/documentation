

IBMCompositeJob.error_message
=====================================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: IBMCompositeJob.error_message