

IBMBackend.get_translation_stage_plugin
===========================================================

.. currentmodule:: qiskit_ibm_provider

.. automethod:: IBMBackend.get_translation_stage_plugin