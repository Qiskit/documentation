

QueueInfo.format
========================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: QueueInfo.format