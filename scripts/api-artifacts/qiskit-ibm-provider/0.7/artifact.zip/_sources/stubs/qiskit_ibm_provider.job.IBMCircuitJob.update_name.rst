

IBMCircuitJob.update_name
=================================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: IBMCircuitJob.update_name