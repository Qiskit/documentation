﻿

passes
=====================================

.. automodule:: qiskit_ibm_provider.transpiler.passes

   
   
   

   
   
   

   
   
   