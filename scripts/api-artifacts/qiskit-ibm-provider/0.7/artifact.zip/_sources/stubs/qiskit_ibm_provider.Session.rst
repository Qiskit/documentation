﻿

Session
===========================

.. currentmodule:: qiskit_ibm_provider

.. autoclass:: Session
   :no-members:
   :no-inherited-members:
   :no-special-members:

   
   

   .. rubric:: Attributes

   .. autosummary::
      :toctree: ../stubs/
   
      Session.active
      Session.session_id
   
   

   
   

   .. rubric:: Methods

   .. autosummary::
      :toctree: ../stubs/
   
      Session.cancel
   

   
   