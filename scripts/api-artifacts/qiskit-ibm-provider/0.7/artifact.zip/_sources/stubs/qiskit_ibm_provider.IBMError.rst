﻿

IBMError
============================

.. currentmodule:: qiskit_ibm_provider

.. autoexception:: IBMError