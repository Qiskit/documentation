

IBMCircuitJob.error_message
===================================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: IBMCircuitJob.error_message