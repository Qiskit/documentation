

IBMCompositeJob.from_jobs
=================================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: IBMCompositeJob.from_jobs