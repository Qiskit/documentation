

IBMCircuitJob.client_version
====================================================

.. currentmodule:: qiskit_ibm_provider.job

.. autoproperty:: IBMCircuitJob.client_version