﻿

IBMJobError
===================================

.. currentmodule:: qiskit_ibm_provider.job

.. autoexception:: IBMJobError