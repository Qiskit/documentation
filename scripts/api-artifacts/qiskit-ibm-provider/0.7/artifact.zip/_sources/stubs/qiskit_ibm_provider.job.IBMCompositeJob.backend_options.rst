

IBMCompositeJob.backend_options
=======================================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: IBMCompositeJob.backend_options