

IBMCompositeJob.header
==============================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: IBMCompositeJob.header