

ASAPScheduleAnalysis.is_transformation_pass
============================================================================================

.. currentmodule:: qiskit_ibm_provider.transpiler.passes.scheduling

.. autoproperty:: ASAPScheduleAnalysis.is_transformation_pass