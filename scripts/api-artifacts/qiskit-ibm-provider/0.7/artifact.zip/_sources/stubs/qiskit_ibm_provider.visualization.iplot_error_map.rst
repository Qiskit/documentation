﻿

iplot_error_map
=================================================

.. currentmodule:: qiskit_ibm_provider.visualization

.. autofunction:: iplot_error_map