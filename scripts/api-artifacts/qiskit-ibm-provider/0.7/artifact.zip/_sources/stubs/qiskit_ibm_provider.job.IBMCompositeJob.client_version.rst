

IBMCompositeJob.client_version
======================================================

.. currentmodule:: qiskit_ibm_provider.job

.. autoproperty:: IBMCompositeJob.client_version