

IBMBackend.run
==================================

.. currentmodule:: qiskit_ibm_provider

.. automethod:: IBMBackend.run