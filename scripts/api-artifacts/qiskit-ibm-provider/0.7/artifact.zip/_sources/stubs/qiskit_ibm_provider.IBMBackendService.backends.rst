

IBMBackendService.backends
==============================================

.. currentmodule:: qiskit_ibm_provider

.. automethod:: IBMBackendService.backends