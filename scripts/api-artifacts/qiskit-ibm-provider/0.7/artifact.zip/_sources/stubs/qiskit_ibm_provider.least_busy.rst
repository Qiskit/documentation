﻿

least_busy
==============================

.. currentmodule:: qiskit_ibm_provider

.. autofunction:: least_busy