

IBMBackendService.retrieve_job
==================================================

.. currentmodule:: qiskit_ibm_provider

.. automethod:: IBMBackendService.retrieve_job