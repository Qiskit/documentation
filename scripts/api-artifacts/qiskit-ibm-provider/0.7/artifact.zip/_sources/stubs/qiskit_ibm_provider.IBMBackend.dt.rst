

IBMBackend.dt
=================================

.. currentmodule:: qiskit_ibm_provider

.. autoproperty:: IBMBackend.dt