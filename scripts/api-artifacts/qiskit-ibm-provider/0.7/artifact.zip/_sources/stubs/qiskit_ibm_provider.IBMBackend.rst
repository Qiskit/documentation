﻿

IBMBackend
==============================

.. currentmodule:: qiskit_ibm_provider

.. autoclass:: IBMBackend
   :no-members:
   :no-inherited-members:
   :no-special-members:

   
   

   .. rubric:: Attributes

   .. autosummary::
      :toctree: ../stubs/
   
      IBMBackend.coupling_map
      IBMBackend.dt
      IBMBackend.dtm
      IBMBackend.id_warning_issued
      IBMBackend.instruction_durations
      IBMBackend.instruction_schedule_map
      IBMBackend.instructions
      IBMBackend.max_circuits
      IBMBackend.meas_map
      IBMBackend.num_qubits
      IBMBackend.operation_names
      IBMBackend.operations
      IBMBackend.options
      IBMBackend.provider
      IBMBackend.session
      IBMBackend.target
      IBMBackend.version
      IBMBackend.name
      IBMBackend.description
      IBMBackend.online_date
      IBMBackend.backend_version
   
   

   
   

   .. rubric:: Methods

   .. autosummary::
      :toctree: ../stubs/
   
      IBMBackend.acquire_channel
      IBMBackend.cancel_session
      IBMBackend.close_session
      IBMBackend.configuration
      IBMBackend.control_channel
      IBMBackend.defaults
      IBMBackend.drive_channel
      IBMBackend.get_translation_stage_plugin
      IBMBackend.measure_channel
      IBMBackend.open_session
      IBMBackend.properties
      IBMBackend.qubit_properties
      IBMBackend.run
      IBMBackend.set_options
      IBMBackend.status
      IBMBackend.target_history
   

   
   