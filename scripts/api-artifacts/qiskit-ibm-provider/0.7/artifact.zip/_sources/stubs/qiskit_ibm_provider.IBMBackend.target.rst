

IBMBackend.target
=====================================

.. currentmodule:: qiskit_ibm_provider

.. autoproperty:: IBMBackend.target