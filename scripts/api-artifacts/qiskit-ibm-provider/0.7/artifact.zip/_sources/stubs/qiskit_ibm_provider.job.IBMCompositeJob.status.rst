

IBMCompositeJob.status
==============================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: IBMCompositeJob.status