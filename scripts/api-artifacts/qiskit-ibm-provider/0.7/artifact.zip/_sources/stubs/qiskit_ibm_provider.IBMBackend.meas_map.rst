

IBMBackend.meas_map
=======================================

.. currentmodule:: qiskit_ibm_provider

.. autoproperty:: IBMBackend.meas_map