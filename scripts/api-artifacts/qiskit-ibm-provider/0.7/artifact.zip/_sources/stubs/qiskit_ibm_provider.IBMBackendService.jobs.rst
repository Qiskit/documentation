

IBMBackendService.jobs
==========================================

.. currentmodule:: qiskit_ibm_provider

.. automethod:: IBMBackendService.jobs