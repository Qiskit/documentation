

IBMCircuitJob.time_per_step
===================================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: IBMCircuitJob.time_per_step