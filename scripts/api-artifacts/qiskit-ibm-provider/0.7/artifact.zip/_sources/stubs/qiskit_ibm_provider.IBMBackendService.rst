﻿

IBMBackendService
=====================================

.. currentmodule:: qiskit_ibm_provider

.. autoclass:: IBMBackendService
   :no-members:
   :no-inherited-members:
   :no-special-members:

   
   
   

   
   

   .. rubric:: Methods

   .. autosummary::
      :toctree: ../stubs/
   
      IBMBackendService.backends
      IBMBackendService.jobs
      IBMBackendService.retrieve_job
   

   
   