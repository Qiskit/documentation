

IBMBackend.open_session
===========================================

.. currentmodule:: qiskit_ibm_provider

.. automethod:: IBMBackend.open_session