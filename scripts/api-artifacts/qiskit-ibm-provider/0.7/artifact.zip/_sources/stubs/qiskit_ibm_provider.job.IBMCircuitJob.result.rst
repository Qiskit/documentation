

IBMCircuitJob.result
============================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: IBMCircuitJob.result