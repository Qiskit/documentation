

IBMProvider.backends
========================================

.. currentmodule:: qiskit_ibm_provider

.. automethod:: IBMProvider.backends