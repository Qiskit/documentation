﻿

IBMBackendError
===================================

.. currentmodule:: qiskit_ibm_provider

.. autoexception:: IBMBackendError