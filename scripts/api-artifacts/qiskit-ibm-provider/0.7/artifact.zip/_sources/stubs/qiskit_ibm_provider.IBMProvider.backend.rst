

IBMProvider.backend
=======================================

.. currentmodule:: qiskit_ibm_provider

.. autoproperty:: IBMProvider.backend