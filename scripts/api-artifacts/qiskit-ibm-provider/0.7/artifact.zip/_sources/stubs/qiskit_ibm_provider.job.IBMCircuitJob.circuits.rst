

IBMCircuitJob.circuits
==============================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: IBMCircuitJob.circuits