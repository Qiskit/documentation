

IBMBackend.dtm
==================================

.. currentmodule:: qiskit_ibm_provider

.. autoproperty:: IBMBackend.dtm