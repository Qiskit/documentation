﻿

iplot_gate_map
================================================

.. currentmodule:: qiskit_ibm_provider.visualization

.. autofunction:: iplot_gate_map