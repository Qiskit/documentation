

IBMCompositeJob.block_for_submit
========================================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: IBMCompositeJob.block_for_submit