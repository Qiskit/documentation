

BlockBasePadder.__call__
=========================================================================

.. currentmodule:: qiskit_ibm_provider.transpiler.passes.scheduling

.. automethod:: BlockBasePadder.__call__