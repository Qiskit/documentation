

IBMBackend.properties
=========================================

.. currentmodule:: qiskit_ibm_provider

.. automethod:: IBMBackend.properties