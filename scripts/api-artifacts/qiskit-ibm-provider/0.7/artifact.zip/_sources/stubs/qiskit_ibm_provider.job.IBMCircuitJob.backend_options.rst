

IBMCircuitJob.backend_options
=====================================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: IBMCircuitJob.backend_options