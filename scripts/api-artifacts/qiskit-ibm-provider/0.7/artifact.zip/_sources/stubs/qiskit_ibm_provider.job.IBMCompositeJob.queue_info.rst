

IBMCompositeJob.queue_info
==================================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: IBMCompositeJob.queue_info