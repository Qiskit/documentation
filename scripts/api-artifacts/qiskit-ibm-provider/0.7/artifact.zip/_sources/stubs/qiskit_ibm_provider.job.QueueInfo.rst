﻿

QueueInfo
=================================

.. currentmodule:: qiskit_ibm_provider.job

.. autoclass:: QueueInfo
   :no-members:
   :no-inherited-members:
   :no-special-members:

   
   

   .. rubric:: Attributes

   .. autosummary::
      :toctree: ../stubs/
   
      QueueInfo.estimated_complete_time
      QueueInfo.estimated_start_time
   
   

   
   

   .. rubric:: Methods

   .. autosummary::
      :toctree: ../stubs/
   
      QueueInfo.format
   

   
   