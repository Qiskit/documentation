

BlockBasePadder.is_analysis_pass
=================================================================================

.. currentmodule:: qiskit_ibm_provider.transpiler.passes.scheduling

.. autoproperty:: BlockBasePadder.is_analysis_pass