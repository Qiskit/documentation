

PadDynamicalDecoupling.__call__
================================================================================

.. currentmodule:: qiskit_ibm_provider.transpiler.passes.scheduling

.. automethod:: PadDynamicalDecoupling.__call__