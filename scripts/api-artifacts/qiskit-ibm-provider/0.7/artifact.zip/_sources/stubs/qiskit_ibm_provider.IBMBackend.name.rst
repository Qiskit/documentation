

IBMBackend.name
===================================

.. currentmodule:: qiskit_ibm_provider

.. autoattribute:: IBMBackend.name