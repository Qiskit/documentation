

QueueInfo.estimated_start_time
======================================================

.. currentmodule:: qiskit_ibm_provider.job

.. autoproperty:: QueueInfo.estimated_start_time