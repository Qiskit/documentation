

IBMBackend.session
======================================

.. currentmodule:: qiskit_ibm_provider

.. autoproperty:: IBMBackend.session