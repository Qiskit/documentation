

DynamicCircuitInstructionDurations.update
==========================================================================================

.. currentmodule:: qiskit_ibm_provider.transpiler.passes.scheduling

.. automethod:: DynamicCircuitInstructionDurations.update