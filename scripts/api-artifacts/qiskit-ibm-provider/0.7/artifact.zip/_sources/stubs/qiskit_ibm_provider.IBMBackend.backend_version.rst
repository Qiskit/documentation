

IBMBackend.backend_version
==============================================

.. currentmodule:: qiskit_ibm_provider

.. autoattribute:: IBMBackend.backend_version