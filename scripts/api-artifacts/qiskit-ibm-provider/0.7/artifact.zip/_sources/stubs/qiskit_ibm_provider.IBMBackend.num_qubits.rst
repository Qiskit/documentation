

IBMBackend.num_qubits
=========================================

.. currentmodule:: qiskit_ibm_provider

.. autoproperty:: IBMBackend.num_qubits