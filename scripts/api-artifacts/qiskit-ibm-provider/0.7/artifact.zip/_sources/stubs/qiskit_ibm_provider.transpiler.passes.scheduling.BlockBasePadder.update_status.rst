

BlockBasePadder.update_status
==============================================================================

.. currentmodule:: qiskit_ibm_provider.transpiler.passes.scheduling

.. automethod:: BlockBasePadder.update_status