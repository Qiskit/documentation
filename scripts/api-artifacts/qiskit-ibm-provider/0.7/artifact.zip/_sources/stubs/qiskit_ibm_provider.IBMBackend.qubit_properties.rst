

IBMBackend.qubit_properties
===============================================

.. currentmodule:: qiskit_ibm_provider

.. automethod:: IBMBackend.qubit_properties