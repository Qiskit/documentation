

IBMCompositeJob.time_per_step
=====================================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: IBMCompositeJob.time_per_step