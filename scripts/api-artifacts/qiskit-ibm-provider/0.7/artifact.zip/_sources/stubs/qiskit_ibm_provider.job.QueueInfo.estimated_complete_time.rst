

QueueInfo.estimated_complete_time
=========================================================

.. currentmodule:: qiskit_ibm_provider.job

.. autoproperty:: QueueInfo.estimated_complete_time