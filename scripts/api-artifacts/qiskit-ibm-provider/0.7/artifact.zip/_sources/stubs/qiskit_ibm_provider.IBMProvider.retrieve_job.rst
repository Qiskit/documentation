

IBMProvider.retrieve_job
============================================

.. currentmodule:: qiskit_ibm_provider

.. automethod:: IBMProvider.retrieve_job