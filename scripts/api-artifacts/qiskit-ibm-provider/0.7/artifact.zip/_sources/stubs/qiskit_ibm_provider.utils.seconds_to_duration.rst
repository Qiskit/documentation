﻿

seconds_to_duration
=============================================

.. currentmodule:: qiskit_ibm_provider.utils

.. autofunction:: seconds_to_duration