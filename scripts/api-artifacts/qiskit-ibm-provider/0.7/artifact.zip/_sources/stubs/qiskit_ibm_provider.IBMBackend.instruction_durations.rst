

IBMBackend.instruction_durations
====================================================

.. currentmodule:: qiskit_ibm_provider

.. autoproperty:: IBMBackend.instruction_durations