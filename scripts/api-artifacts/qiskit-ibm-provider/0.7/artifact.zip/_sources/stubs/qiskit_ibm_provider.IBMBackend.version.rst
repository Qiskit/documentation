

IBMBackend.version
======================================

.. currentmodule:: qiskit_ibm_provider

.. autoattribute:: IBMBackend.version