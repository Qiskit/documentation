

IBMCompositeJob.properties
==================================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: IBMCompositeJob.properties