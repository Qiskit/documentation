

IBMCompositeJob.update_tags
===================================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: IBMCompositeJob.update_tags