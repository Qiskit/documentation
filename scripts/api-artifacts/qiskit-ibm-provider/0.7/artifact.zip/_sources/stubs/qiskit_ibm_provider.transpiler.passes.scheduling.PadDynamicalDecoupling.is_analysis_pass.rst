

PadDynamicalDecoupling.is_analysis_pass
========================================================================================

.. currentmodule:: qiskit_ibm_provider.transpiler.passes.scheduling

.. autoproperty:: PadDynamicalDecoupling.is_analysis_pass