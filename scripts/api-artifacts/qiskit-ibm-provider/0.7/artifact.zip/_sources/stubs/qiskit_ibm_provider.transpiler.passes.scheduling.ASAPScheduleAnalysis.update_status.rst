

ASAPScheduleAnalysis.update_status
===================================================================================

.. currentmodule:: qiskit_ibm_provider.transpiler.passes.scheduling

.. automethod:: ASAPScheduleAnalysis.update_status