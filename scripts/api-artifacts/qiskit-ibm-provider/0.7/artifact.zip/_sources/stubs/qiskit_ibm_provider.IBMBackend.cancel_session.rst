

IBMBackend.cancel_session
=============================================

.. currentmodule:: qiskit_ibm_provider

.. automethod:: IBMBackend.cancel_session