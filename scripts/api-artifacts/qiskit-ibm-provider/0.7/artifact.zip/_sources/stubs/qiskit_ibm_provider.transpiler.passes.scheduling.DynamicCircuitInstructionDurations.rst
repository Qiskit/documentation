

DynamicCircuitInstructionDurations
===================================================================================

.. currentmodule:: qiskit_ibm_provider.transpiler.passes.scheduling

.. autoclass:: DynamicCircuitInstructionDurations
   :no-members:
   :no-inherited-members:
   :no-special-members:

   
   

   .. rubric:: Attributes

   .. autosummary::
      :toctree: ../stubs/
   
      DynamicCircuitInstructionDurations.MEASURE_PATCH_CYCLES
      DynamicCircuitInstructionDurations.MEASURE_PATCH_ODD_OFFSET
   
   

   
   

   .. rubric:: Methods

   .. autosummary::
      :toctree: ../stubs/
   
      DynamicCircuitInstructionDurations.from_backend
      DynamicCircuitInstructionDurations.get
      DynamicCircuitInstructionDurations.units_used
      DynamicCircuitInstructionDurations.update
   

   
   