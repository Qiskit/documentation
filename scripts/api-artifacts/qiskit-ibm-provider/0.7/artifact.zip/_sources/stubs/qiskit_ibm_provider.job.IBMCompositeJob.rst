﻿

IBMCompositeJob
=======================================

.. currentmodule:: qiskit_ibm_provider.job

.. autoclass:: IBMCompositeJob
   :no-members:
   :no-inherited-members:
   :no-special-members:

   
   

   .. rubric:: Attributes

   .. autosummary::
      :toctree: ../stubs/
   
      IBMCompositeJob.client_version
      IBMCompositeJob.version
   
   

   
   

   .. rubric:: Methods

   .. autosummary::
      :toctree: ../stubs/
   
      IBMCompositeJob.backend
      IBMCompositeJob.backend_options
      IBMCompositeJob.block_for_submit
      IBMCompositeJob.cancel
      IBMCompositeJob.cancelled
      IBMCompositeJob.circuits
      IBMCompositeJob.creation_date
      IBMCompositeJob.done
      IBMCompositeJob.error_message
      IBMCompositeJob.from_jobs
      IBMCompositeJob.header
      IBMCompositeJob.in_final_state
      IBMCompositeJob.job_id
      IBMCompositeJob.name
      IBMCompositeJob.properties
      IBMCompositeJob.queue_info
      IBMCompositeJob.queue_position
      IBMCompositeJob.refresh
      IBMCompositeJob.report
      IBMCompositeJob.rerun_failed
      IBMCompositeJob.result
      IBMCompositeJob.running
      IBMCompositeJob.scheduling_mode
      IBMCompositeJob.status
      IBMCompositeJob.sub_job
      IBMCompositeJob.sub_jobs
      IBMCompositeJob.submit
      IBMCompositeJob.tags
      IBMCompositeJob.time_per_step
      IBMCompositeJob.update_name
      IBMCompositeJob.update_tags
      IBMCompositeJob.wait_for_final_state
   

   
   