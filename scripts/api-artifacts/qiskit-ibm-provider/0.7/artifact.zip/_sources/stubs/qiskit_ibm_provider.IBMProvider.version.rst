

IBMProvider.version
=======================================

.. currentmodule:: qiskit_ibm_provider

.. autoattribute:: IBMProvider.version