﻿

validate_job_tags
===========================================

.. currentmodule:: qiskit_ibm_provider.utils

.. autofunction:: validate_job_tags