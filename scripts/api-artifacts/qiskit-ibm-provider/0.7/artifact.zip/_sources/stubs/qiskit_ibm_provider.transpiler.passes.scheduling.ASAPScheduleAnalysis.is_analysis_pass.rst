

ASAPScheduleAnalysis.is_analysis_pass
======================================================================================

.. currentmodule:: qiskit_ibm_provider.transpiler.passes.scheduling

.. autoproperty:: ASAPScheduleAnalysis.is_analysis_pass