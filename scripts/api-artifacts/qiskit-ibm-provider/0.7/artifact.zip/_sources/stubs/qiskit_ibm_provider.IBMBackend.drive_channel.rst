

IBMBackend.drive_channel
============================================

.. currentmodule:: qiskit_ibm_provider

.. automethod:: IBMBackend.drive_channel