

IBMCompositeJob.scheduling_mode
=======================================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: IBMCompositeJob.scheduling_mode