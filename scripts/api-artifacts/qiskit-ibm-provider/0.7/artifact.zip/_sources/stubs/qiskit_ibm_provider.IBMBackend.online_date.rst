

IBMBackend.online_date
==========================================

.. currentmodule:: qiskit_ibm_provider

.. autoattribute:: IBMBackend.online_date