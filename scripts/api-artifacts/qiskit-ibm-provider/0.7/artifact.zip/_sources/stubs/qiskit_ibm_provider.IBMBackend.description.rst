

IBMBackend.description
==========================================

.. currentmodule:: qiskit_ibm_provider

.. autoattribute:: IBMBackend.description