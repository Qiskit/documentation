

DynamicCircuitInstructionDurations.from_backend
================================================================================================

.. currentmodule:: qiskit_ibm_provider.transpiler.passes.scheduling

.. automethod:: DynamicCircuitInstructionDurations.from_backend