

IBMBackend.measure_channel
==============================================

.. currentmodule:: qiskit_ibm_provider

.. automethod:: IBMBackend.measure_channel