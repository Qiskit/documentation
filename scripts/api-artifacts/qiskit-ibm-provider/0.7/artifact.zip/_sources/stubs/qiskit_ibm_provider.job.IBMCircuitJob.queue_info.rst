

IBMCircuitJob.queue_info
================================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: IBMCircuitJob.queue_info