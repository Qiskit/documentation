

IBMBackend.target_history
=============================================

.. currentmodule:: qiskit_ibm_provider

.. automethod:: IBMBackend.target_history