

IBMBackend.coupling_map
===========================================

.. currentmodule:: qiskit_ibm_provider

.. autoproperty:: IBMBackend.coupling_map