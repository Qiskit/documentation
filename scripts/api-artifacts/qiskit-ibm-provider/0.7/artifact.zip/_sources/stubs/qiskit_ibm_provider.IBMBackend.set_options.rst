

IBMBackend.set_options
==========================================

.. currentmodule:: qiskit_ibm_provider

.. automethod:: IBMBackend.set_options