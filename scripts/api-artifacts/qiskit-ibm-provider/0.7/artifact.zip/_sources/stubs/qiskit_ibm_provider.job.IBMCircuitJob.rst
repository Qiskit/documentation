﻿

IBMCircuitJob
=====================================

.. currentmodule:: qiskit_ibm_provider.job

.. autoclass:: IBMCircuitJob
   :no-members:
   :no-inherited-members:
   :no-special-members:

   
   

   .. rubric:: Attributes

   .. autosummary::
      :toctree: ../stubs/
   
      IBMCircuitJob.client_version
      IBMCircuitJob.usage_estimation
      IBMCircuitJob.version
   
   

   
   

   .. rubric:: Methods

   .. autosummary::
      :toctree: ../stubs/
   
      IBMCircuitJob.backend
      IBMCircuitJob.backend_options
      IBMCircuitJob.cancel
      IBMCircuitJob.cancelled
      IBMCircuitJob.circuits
      IBMCircuitJob.creation_date
      IBMCircuitJob.done
      IBMCircuitJob.error_message
      IBMCircuitJob.header
      IBMCircuitJob.in_final_state
      IBMCircuitJob.job_id
      IBMCircuitJob.name
      IBMCircuitJob.properties
      IBMCircuitJob.queue_info
      IBMCircuitJob.queue_position
      IBMCircuitJob.refresh
      IBMCircuitJob.result
      IBMCircuitJob.running
      IBMCircuitJob.scheduling_mode
      IBMCircuitJob.status
      IBMCircuitJob.submit
      IBMCircuitJob.tags
      IBMCircuitJob.time_per_step
      IBMCircuitJob.update_name
      IBMCircuitJob.update_tags
      IBMCircuitJob.wait_for_final_state
   

   
   