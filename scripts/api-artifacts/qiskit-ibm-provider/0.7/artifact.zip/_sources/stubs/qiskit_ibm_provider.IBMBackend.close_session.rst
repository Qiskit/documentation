

IBMBackend.close_session
============================================

.. currentmodule:: qiskit_ibm_provider

.. automethod:: IBMBackend.close_session