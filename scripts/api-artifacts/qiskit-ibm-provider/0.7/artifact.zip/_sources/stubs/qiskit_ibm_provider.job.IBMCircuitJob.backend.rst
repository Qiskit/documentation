

IBMCircuitJob.backend
=============================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: IBMCircuitJob.backend