

ALAPScheduleAnalysis.name
==========================================================================

.. currentmodule:: qiskit_ibm_provider.transpiler.passes.scheduling

.. automethod:: ALAPScheduleAnalysis.name