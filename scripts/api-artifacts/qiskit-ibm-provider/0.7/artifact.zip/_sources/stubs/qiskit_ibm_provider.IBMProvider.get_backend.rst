

IBMProvider.get_backend
===========================================

.. currentmodule:: qiskit_ibm_provider

.. automethod:: IBMProvider.get_backend