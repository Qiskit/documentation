

IBMProvider.active_account
==============================================

.. currentmodule:: qiskit_ibm_provider

.. automethod:: IBMProvider.active_account