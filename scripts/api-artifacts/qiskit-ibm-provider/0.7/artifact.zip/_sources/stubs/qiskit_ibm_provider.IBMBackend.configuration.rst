

IBMBackend.configuration
============================================

.. currentmodule:: qiskit_ibm_provider

.. automethod:: IBMBackend.configuration