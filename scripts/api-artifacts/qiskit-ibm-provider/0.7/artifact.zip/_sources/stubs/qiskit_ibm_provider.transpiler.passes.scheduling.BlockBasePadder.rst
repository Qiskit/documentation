

BlockBasePadder
================================================================

.. currentmodule:: qiskit_ibm_provider.transpiler.passes.scheduling

.. autoclass:: BlockBasePadder
   :no-members:
   :no-inherited-members:
   :no-special-members:

   
   

   .. rubric:: Attributes

   .. autosummary::
      :toctree: ../stubs/
   
      BlockBasePadder.is_analysis_pass
      BlockBasePadder.is_transformation_pass
   
   

   
   

   .. rubric:: Methods

   .. autosummary::
      :toctree: ../stubs/
   
      BlockBasePadder.__call__
      BlockBasePadder.execute
      BlockBasePadder.name
      BlockBasePadder.run
      BlockBasePadder.update_status
   
      BlockBasePadder.__call__

   
   