

IBMCircuitJob.status
============================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: IBMCircuitJob.status