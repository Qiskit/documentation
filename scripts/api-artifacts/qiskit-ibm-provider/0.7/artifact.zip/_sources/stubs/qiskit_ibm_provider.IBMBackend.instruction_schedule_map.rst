

IBMBackend.instruction_schedule_map
=======================================================

.. currentmodule:: qiskit_ibm_provider

.. autoproperty:: IBMBackend.instruction_schedule_map