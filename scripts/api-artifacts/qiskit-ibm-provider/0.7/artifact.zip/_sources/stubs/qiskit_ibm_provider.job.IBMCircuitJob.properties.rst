

IBMCircuitJob.properties
================================================

.. currentmodule:: qiskit_ibm_provider.job

.. automethod:: IBMCircuitJob.properties