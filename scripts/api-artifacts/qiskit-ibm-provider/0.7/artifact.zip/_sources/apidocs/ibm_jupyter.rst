.. _qiskit_ibm_provider-jupyter:

.. automodule:: qiskit_ibm_provider.jupyter
   :no-members:
   :no-inherited-members:
   :no-special-members:
